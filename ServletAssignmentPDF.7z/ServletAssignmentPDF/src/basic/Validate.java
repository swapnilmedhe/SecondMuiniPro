package basic;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Validate
 */
@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public Validate() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		int choice = Integer.parseInt(request.getParameter("year"));
		System.out.println("Choice is: "+choice);
		String filepath;
		if(choice == 1){
			filepath="D:/Assignment/J2EE_Assignment/ServletAssignmentPDF/MCA1.pdf";
			response.sendRedirect("ViewPDF?user_name="+filepath+"");
		}
		else if(choice ==2){
			filepath="D:/Assignment/J2EE_Assignment/ServletAssignmentPDF/MCA2.pdf";
			response.sendRedirect("ViewPDF?user_name="+filepath+"");
		}
		
		else if(choice ==3){
			filepath="D:/Assignment/J2EE_Assignment/ServletAssignmentPDF/MCA3.pdf";
			response.sendRedirect("ViewPDF?user_name="+filepath+"");
		}
		
		else{
			System.out.println("Choose the option");
		}
		
		}
		
		


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
